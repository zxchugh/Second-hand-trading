package com.entity;
public class Article {
private String articleid;
public String getArticleid() { return articleid; }
public void setArticleid(String articleid) { this.articleid = articleid; }
private String title;
public String getTitle() { return this.title; }
public void setTitle(String title) { this.title = title; }
private String image;
public String getImage() { return this.image; }
public void setImage(String image) { this.image = image; }
private String contents;
public String getContents() { return this.contents; }
public void setContents(String contents) { this.contents = contents; }
private String addtime;
public String getAddtime() { return this.addtime; }
public void setAddtime(String addtime) { this.addtime = addtime; }
private String hits;
public String getHits() { return this.hits; }
public void setHits(String hits) { this.hits = hits; }
}
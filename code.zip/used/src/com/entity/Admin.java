package com.entity;
public class Admin {
private String adminid;
public String getAdminid() { return adminid; }
public void setAdminid(String adminid) { this.adminid = adminid; }
private String username;
public String getUsername() { return this.username; }
public void setUsername(String username) { this.username = username; }
private String password;
public String getPassword() { return this.password; }
public void setPassword(String password) { this.password = password; }
private String realname;
public String getRealname() { return this.realname; }
public void setRealname(String realname) { this.realname = realname; }
private String contact;
public String getContact() { return this.contact; }
public void setContact(String contact) { this.contact = contact; }
}
package com.entity;
public class Cart {
private String cartid;
public String getCartid() { return cartid; }
public void setCartid(String cartid) { this.cartid = cartid; }
private Users users;
public Users getUsers() { return users; }
public void setUsers(Users users) { this.users = users; }
private Goods goods;
public Goods getGoods() { return goods; }
public void setGoods(Goods goods) { this.goods = goods; }
private String goodsid;
public String getGoodsid() { return this.goodsid; }
public void setGoodsid(String goodsid) { this.goodsid = goodsid; }
private String usersid;
public String getUsersid() { return this.usersid; }
public void setUsersid(String usersid) { this.usersid = usersid; }
private String price;
public String getPrice() { return this.price; }
public void setPrice(String price) { this.price = price; }
private String num;
public String getNum() { return this.num; }
public void setNum(String num) { this.num = num; }
private String addtime;
public String getAddtime() { return this.addtime; }
public void setAddtime(String addtime) { this.addtime = addtime; }
}
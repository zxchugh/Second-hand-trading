package com.entity;
public class Seller {
private String sellerid;
public String getSellerid() { return sellerid; }
public void setSellerid(String sellerid) { this.sellerid = sellerid; }
private String username;
public String getUsername() { return this.username; }
public void setUsername(String username) { this.username = username; }
private String password;
public String getPassword() { return this.password; }
public void setPassword(String password) { this.password = password; }
private String realname;
public String getRealname() { return this.realname; }
public void setRealname(String realname) { this.realname = realname; }
private String sex;
public String getSex() { return this.sex; }
public void setSex(String sex) { this.sex = sex; }
private String birthday;
public String getBirthday() { return this.birthday; }
public void setBirthday(String birthday) { this.birthday = birthday; }
private String contact;
public String getContact() { return this.contact; }
public void setContact(String contact) { this.contact = contact; }
private String qq;
public String getQq() { return this.qq; }
public void setQq(String qq) { this.qq = qq; }
private String status;
public String getStatus() { return this.status; }
public void setStatus(String status) { this.status = status; }
private String regdate;
public String getRegdate() { return this.regdate; }
public void setRegdate(String regdate) { this.regdate = regdate; }
}
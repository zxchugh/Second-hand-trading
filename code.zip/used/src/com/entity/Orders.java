package com.entity;
public class Orders {
private String ordersid;
public String getOrdersid() { return ordersid; }
public void setOrdersid(String ordersid) { this.ordersid = ordersid; }
private Users users;
public Users getUsers() { return users; }
public void setUsers(Users users) { this.users = users; }
private Goods goods;
public Goods getGoods() { return goods; }
public void setGoods(Goods goods) { this.goods = goods; }
private String ordercode;
public String getOrdercode() { return this.ordercode; }
public void setOrdercode(String ordercode) { this.ordercode = ordercode; }
private String usersid;
public String getUsersid() { return this.usersid; }
public void setUsersid(String usersid) { this.usersid = usersid; }
private String goodsid;
public String getGoodsid() { return this.goodsid; }
public void setGoodsid(String goodsid) { this.goodsid = goodsid; }
private String price;
public String getPrice() { return this.price; }
public void setPrice(String price) { this.price = price; }
private String num;
public String getNum() { return this.num; }
public void setNum(String num) { this.num = num; }
private String addtime;
public String getAddtime() { return this.addtime; }
public void setAddtime(String addtime) { this.addtime = addtime; }
private String status;
public String getStatus() { return this.status; }
public void setStatus(String status) { this.status = status; }
private String receiver;
public String getReceiver() { return this.receiver; }
public void setReceiver(String receiver) { this.receiver = receiver; }
private String address;
public String getAddress() { return this.address; }
public void setAddress(String address) { this.address = address; }
private String contact;
public String getContact() { return this.contact; }
public void setContact(String contact) { this.contact = contact; }
}